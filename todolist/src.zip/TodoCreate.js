import React from 'react';
import './todocreate.css';
import { MdAdd } from 'react-icons/md';

//새로운 할일을 등록하는 컴포넌트
function TodoCreate() {
    return (
        <>
            <div className="formWrap">
                <form>
                    <input type="text" placeholder="할 일을 입력 후, Enter를 누르세요." />
                </form>
            </div>
            <div className="circleBox">
                <MdAdd />
            </div>
        </>
    );
}

export default TodoCreate;