import React from 'react';
import './todolist.css';
import TodoItem from './TodoItem';

//리스트를 묶어서 한번에 처리 - map()
function TodoList() {
    return (
        <div className="todolistbox">
            <TodoItem />
        </div>
    );
}

export default TodoList;