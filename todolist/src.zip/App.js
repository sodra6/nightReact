import React from 'react';
import './App.css';
import TodoBox from './TodoBox';
import TodoHeader from './TodoHeader';
import TodoList from './TodoList';
import TodoCreate from './TodoCreate';

function App() {
  return (
    <div>
      <TodoBox>
        <TodoHeader />
        <TodoList />
        <TodoCreate />
      </TodoBox>
    </div>
  );
}

export default App;