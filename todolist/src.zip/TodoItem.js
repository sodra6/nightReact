import React from 'react';
import './todoitem.css';
import { MdDone, MdDelete } from 'react-icons/md';
//react-icons 라이브러리 중 아이콘 2개 불러옴

//각각 할일 정보를 표시
//체크박스 + 할일텍스트 + 마우스오버시 휴지통아이콘
function TodoItem() {
    return (
        <div className="todoitembox">
            <div className="checkcircle">
                <MdDone />
            </div>
            <p>할일 구현</p>
            <div className="remove">
                <MdDelete />
            </div>
        </div>
    );
}

export default TodoItem;